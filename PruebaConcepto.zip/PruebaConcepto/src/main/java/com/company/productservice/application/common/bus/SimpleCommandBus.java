package com.company.productservice.application.common.bus;
import com.company.productservice.application.common.Command;
import com.company.productservice.application.common.handlers.CommandHandler;
import java.util.HashMap;
import java.util.Map;
/**
 * Implementación simple del bus de comandos
 * Mantiene un registro de manejadores para cada tipo de comando
 */
public class SimpleCommandBus implements CommandBus {
    // Mapa que asocia tipos de comandos con sus manejadores
    private final Map<Class<?>, CommandHandler<?, ?>> handlers = new HashMap<>();

    /**
     * Registra un manejador para un tipo específico de comando
     *
     * @param commandClass Clase del comando
     * @param handler Manejador del comando
     */
    public <C extends Command<R>, R> void register(Class<C> commandClass, CommandHandler<C, R> handler) {
        handlers.put(commandClass, handler);
    }

    /**
     * Ejecuta un comando usando su manejador registrado
     *
     * @param command El comando a ejecutar
     * @return El resultado de la ejecución del comando
     * @throws IllegalArgumentException si no hay un manejador registrado para el comando
     */
    @SuppressWarnings("unchecked")
    @Override
    public <R> R execute(Command<R> command) {
        CommandHandler<Command<R>, R> handler = (CommandHandler<Command<R>, R>) handlers.get(command.getClass());
        if (handler == null) {
            throw new IllegalArgumentException("No handler registered for " + command.getClass().getName());
        }
        return handler.handle(command);
    }
}