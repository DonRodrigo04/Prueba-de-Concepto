package com.company.productservice.infrastructure.persistence;
import com.company.productservice.domain.model.Product;
import com.company.productservice.domain.repository.ProductRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Interfaz de repositorio JPA para la entidad Product
 * Extiende JpaRepository para obtener operaciones CRUD básicas
 */
@Repository
public interface JpaProductRepository extends JpaRepository<Product, UUID> {

    /**
     * Busca un producto por su SKU
     *
     * @param sku SKU del producto
     * @return Producto si existe
     */
    Optional<Product> findBySku(String sku);

    /**
     * Verifica si existe un producto con el SKU proporcionado
     *
     * @param sku SKU a verificar
     * @return true si existe, false en caso contrario
     */
    boolean existsBySku(String sku);

    /**
     * Consulta personalizada para buscar productos con filtros
     *
     * @param name Filtro de nombre (opcional)
     * @param category Filtro de categoría (opcional)
     * @param minPrice Precio mínimo (opcional)
     * @param maxPrice Precio máximo (opcional)
     * @param active Filtrar solo activos (opcional)
     * @return Lista de productos que cumplen los criterios
     */
    @Query("SELECT p FROM Product p WHERE " +
            "(:name IS NULL OR p.name LIKE %:name%) AND " +
            "(:category IS NULL OR p.category = :category) AND " +
            "(:minPrice IS NULL OR p.price >= :minPrice) AND " +
            "(:maxPrice IS NULL OR p.price <= :maxPrice) AND " +
            "(:active IS NULL OR p.active = :active)")
    List<Product> findByFilters(@Param("name") String name,
                                @Param("category") String category,
                                @Param("minPrice") Double minPrice,
                                @Param("maxPrice") Double maxPrice,
                                @Param("active") Boolean active,
                                PageRequest pageRequest);
}
