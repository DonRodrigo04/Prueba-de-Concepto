package com.company.productservice.application.common;

/**
 * Excepción base para todas las excepciones de aplicación
 * Permite diferenciar excepciones de negocio de excepciones técnicas
 */
public class ApplicationException extends RuntimeException {
    private final String errorCode;

    /**
     * Constructor principal que acepta un mensaje descriptivo y un código de error.
     *
     * @param message Descripción legible del error para diagnóstico
     * @param errorCode Código que identifica el tipo de error (ej. "PRODUCT_NOT_FOUND")
     */
    public ApplicationException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    /**
     * Constructor secundario que también acepta una excepción causa.
     *
     * @param message Descripción legible del error
     * @param errorCode Código que identifica el tipo de error
     * @param cause Excepción original que provocó este error
     */
    public ApplicationException(String message, String errorCode, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    //Método getter para obtener el código de error.
    public String getErrorCode() {
        return errorCode;
    }
}