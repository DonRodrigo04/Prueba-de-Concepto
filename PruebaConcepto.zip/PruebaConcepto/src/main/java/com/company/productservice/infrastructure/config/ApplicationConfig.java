package com.company.productservice.infrastructure.config;

import com.company.productservice.application.command.handlers.CreateProductCommandHandler;
import com.company.productservice.application.command.handlers.UpdateProductStockCommandHandler;
import com.company.productservice.application.command.models.CreateProductCommand;
import com.company.productservice.application.command.models.UpdateProductStockCommand;
import com.company.productservice.application.common.bus.CommandBus;
import com.company.productservice.application.common.bus.QueryBus;
import com.company.productservice.application.common.bus.SimpleCommandBus;
import com.company.productservice.application.common.bus.SimpleQueryBus;
import com.company.productservice.application.events.DomainEventPublisher;
import com.company.productservice.application.query.handlers.FindProductsQueryHandler;
import com.company.productservice.application.query.handlers.GetProductByIdQueryHandler;
import com.company.productservice.application.query.models.FindProductsQuery;
import com.company.productservice.application.query.models.GetProductByIdQuery;
import com.company.productservice.domain.repository.ProductRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuración de la aplicación
 * Registra los manejadores de comandos y consultas en sus respectivos buses
 */
@Configuration
public class ApplicationConfig {

    @Bean
    public CommandBus commandBus(
            CreateProductCommandHandler createProductCommandHandler,
            UpdateProductStockCommandHandler updateProductStockCommandHandler) {

        SimpleCommandBus commandBus = new SimpleCommandBus();

        // Registrar los manejadores de comandos
        commandBus.register(CreateProductCommand.class, createProductCommandHandler);
        commandBus.register(UpdateProductStockCommand.class, updateProductStockCommandHandler);

        return commandBus;
    }

    @Bean
    public QueryBus queryBus(
            GetProductByIdQueryHandler getProductByIdQueryHandler,
            FindProductsQueryHandler findProductsQueryHandler) {

        SimpleQueryBus queryBus = new SimpleQueryBus();

        // Registrar los manejadores de consultas
        queryBus.register(GetProductByIdQuery.class, getProductByIdQueryHandler);
        queryBus.register(FindProductsQuery.class, findProductsQueryHandler);

        return queryBus;
    }

    @Bean
    public CreateProductCommandHandler createProductCommandHandler(
            ProductRepository productRepository,
            DomainEventPublisher eventPublisher) {
        return new CreateProductCommandHandler(productRepository, eventPublisher);
    }

    @Bean
    public UpdateProductStockCommandHandler updateProductStockCommandHandler(
            ProductRepository productRepository,
            DomainEventPublisher eventPublisher) {
        return new UpdateProductStockCommandHandler(productRepository, eventPublisher);
    }

    @Bean
    public GetProductByIdQueryHandler getProductByIdQueryHandler(
            ProductRepository productRepository) {
        return new GetProductByIdQueryHandler(productRepository);
    }

    @Bean
    public FindProductsQueryHandler findProductsQueryHandler(
            ProductRepository productRepository) {
        return new FindProductsQueryHandler(productRepository);
    }
}