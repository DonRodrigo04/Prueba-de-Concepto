package com.company.productservice.application.command.models;
import com.company.productservice.application.common.Command;
import java.math.BigDecimal;
/**
 * Comando para crear un nuevo producto
 * Contiene todos los datos necesarios para la creación
 * Devuelve el ID del producto creado como UUID en formato String
 */
public class CreateProductCommand implements Command<String> {
    private final String name;
    private final String description;
    private final String sku;
    private final BigDecimal price;
    private final int stockQuantity;
    private final String category;

    public CreateProductCommand(String name, String description, String sku,
                                BigDecimal price, int stockQuantity, String category) {
        this.name = name;
        this.description = description;
        this.sku = sku;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getSku() {
        return sku;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public String getCategory() {
        return category;
    }
}