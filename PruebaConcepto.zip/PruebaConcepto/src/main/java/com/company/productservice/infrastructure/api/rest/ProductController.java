package com.company.productservice.infrastructure.api.rest;

import com.company.productservice.application.command.models.CreateProductCommand;
import com.company.productservice.application.command.models.UpdateProductPriceCommand;
import com.company.productservice.application.command.models.UpdateProductStockCommand;
import com.company.productservice.application.common.bus.CommandBus;
import com.company.productservice.application.common.bus.QueryBus;
import com.company.productservice.application.query.models.FindProductsQuery;
import com.company.productservice.application.query.models.GetProductByIdQuery;
import com.company.productservice.application.query.models.ProductDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

/**
 * Controlador REST para operaciones con productos
 * Actúa como adaptador primario entre clientes HTTP y la aplicación
 */
@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final CommandBus commandBus;
    private final QueryBus queryBus;

    public ProductController(CommandBus commandBus, QueryBus queryBus) {
        this.commandBus = commandBus;
        this.queryBus = queryBus;
    }

    /**
     * Crea un nuevo producto
     */
    @PostMapping
    public ResponseEntity<CreateProductResponse> createProduct(@RequestBody CreateProductRequest request) {
        String productId = commandBus.execute(new CreateProductCommand(
                request.getName(),
                request.getDescription(),
                request.getSku(),
                request.getPrice(),
                request.getStockQuantity(),
                request.getCategory()
        ));

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new CreateProductResponse(productId, "Product created successfully"));
    }

    /**
     * Obtiene un producto por su ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<ProductDto> getProductById(@PathVariable String id) {
        ProductDto product = queryBus.execute(new GetProductByIdQuery(UUID.fromString(id)));
        return ResponseEntity.ok(product);
    }

    /**
     * Busca productos con filtros
     */
    @GetMapping
    public ResponseEntity<List<ProductDto>> findProducts(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) Boolean onlyActive,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        List<ProductDto> products = queryBus.execute(new FindProductsQuery(
                name, category, minPrice, maxPrice, onlyActive, page, size
        ));

        return ResponseEntity.ok(products);
    }

    /**
     * Actualiza el precio de un producto
     */
    @PatchMapping("/{id}/price")
    public ResponseEntity<Void> updateProductPrice(
            @PathVariable String id,
            @RequestBody UpdateProductPriceRequest request) {

        commandBus.execute(new UpdateProductPriceCommand(
                UUID.fromString(id),
                request.getPrice()
        ));

        return ResponseEntity.noContent().build();
    }

    /**
     * Actualiza el stock de un producto
     */
    @PatchMapping("/{id}/stock")
    public ResponseEntity<Void> updateProductStock(
            @PathVariable String id,
            @RequestBody UpdateProductStockRequest request) {

        commandBus.execute(new UpdateProductStockCommand(
                UUID.fromString(id),
                request.getStockQuantity()
        ));

        return ResponseEntity.noContent().build();
    }

    // Clases DTOs para las peticiones y respuestas HTTP

    public static class CreateProductRequest {
        private String name;
        private String description;
        private String sku;
        private BigDecimal price;
        private int stockQuantity;
        private String category;

        // Getters y setters
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public String getSku() { return sku; }
        public void setSku(String sku) { this.sku = sku; }
        public BigDecimal getPrice() { return price; }
        public void setPrice(BigDecimal price) { this.price = price; }
        public int getStockQuantity() { return stockQuantity; }
        public void setStockQuantity(int stockQuantity) { this.stockQuantity = stockQuantity; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
    }

    public static class CreateProductResponse {
        private final String id;
        private final String message;

        public CreateProductResponse(String id, String message) {
            this.id = id;
            this.message = message;
        }

        public String getId() { return id; }
        public String getMessage() { return message; }
    }

    public static class UpdateProductPriceRequest {
        private BigDecimal price;

        public BigDecimal getPrice() { return price; }
        public void setPrice(BigDecimal price) { this.price = price; }
    }

    public static class UpdateProductStockRequest {
        private int stockQuantity;

        public int getStockQuantity() { return stockQuantity; }
        public void setStockQuantity(int stockQuantity) { this.stockQuantity = stockQuantity; }
    }
}