package com.company.productservice.domain.repository;
import com.company.productservice.domain.model.Product;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
/**
 * Repositorio para operaciones con productos
 * Define el contrato que debe implementar la capa de infraestructura
 */
public interface ProductRepository {
    /**
     * Guarda un producto en el repositorio
     *
     * @param product Producto a guardar
     * @return Producto guardado
     */
    Product save(Product product);

    /**
     * Busca un producto por su ID
     *
     * @param id ID del producto
     * @return Producto encontrado o vacío si no existe
     */
    Optional<Product> findById(UUID id);

    /**
     * Busca un producto por su SKU
     *
     * @param sku SKU del producto
     * @return Producto encontrado o vacío si no existe
     */
    Optional<Product> findBySku(String sku);

    /**
     * Verifica si existe un producto con el SKU especificado
     *
     * @param sku SKU a verificar
     * @return true si existe, false en caso contrario
     */
    boolean existsBySku(String sku);

    /**
     * Busca productos según filtros específicos
     *
     * @param nameFilter Filtro por nombre (puede ser null)
     * @param categoryFilter Filtro por categoría (puede ser null)
     * @param minPrice Precio mínimo (puede ser null)
     * @param maxPrice Precio máximo (puede ser null)
     * @param onlyActive Filtrar solo productos activos
     * @param page Número de página (base 0)
     * @param size Tamaño de página
     * @return Lista de productos que cumplen los criterios
     */
    List<Product> findByFilters(String nameFilter, String categoryFilter,
                                Double minPrice, Double maxPrice,
                                Boolean onlyActive, int page, int size);

    //Elimina un producto del repositorio
    void delete(Product product);

    //Cuenta el número total de productos
    long count();
}