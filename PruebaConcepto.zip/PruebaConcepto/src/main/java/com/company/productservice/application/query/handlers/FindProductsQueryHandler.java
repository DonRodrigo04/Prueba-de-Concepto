package com.company.productservice.application.query.handlers;
import com.company.productservice.application.common.handlers.QueryHandler;
import com.company.productservice.application.query.models.FindProductsQuery;
import com.company.productservice.application.query.models.ProductDto;
import com.company.productservice.domain.model.Product;
import com.company.productservice.domain.repository.ProductRepository;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;
/**
 * Manejador de la consulta FindProductsQuery
 * Implementa la lógica para buscar productos con criterios de filtrado
 */
public class FindProductsQueryHandler implements QueryHandler<FindProductsQuery, List<ProductDto>> {
    private final ProductRepository productRepository;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public FindProductsQueryHandler(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public List<ProductDto> handle(FindProductsQuery query) {
        // Buscar productos con los filtros proporcionados
        List<Product> products = productRepository.findByFilters(
                query.getNameFilter(),
                query.getCategoryFilter(),
                query.getMinPrice(),
                query.getMaxPrice(),
                query.getOnlyActive(),
                query.getPage(),
                query.getSize()
        );

        // Mapear la lista de productos a DTOs
        return products.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private ProductDto mapToDto(Product product) {
        return new ProductDto(
                product.getId(),
                product.getName(),
                product.getDescription(),
                product.getSku(),
                product.getPrice(),
                product.getStockQuantity(),
                product.getCategory(),
                product.isActive(),
                product.getCreatedAt().format(DATE_FORMATTER),
                product.getUpdatedAt().format(DATE_FORMATTER)
        );
    }
}