package com.company.productservice.application.common;
/**
 * Interfaz base para todos los comandos (operaciones de escritura)
 * Sigue el patrón Command del patrón CQRS.
 *
 * @param <R> Tipo de respuesta que devuelve el comando
 */
public interface Command<R> {
    // Interfaz marcadora para identificar comandos
}