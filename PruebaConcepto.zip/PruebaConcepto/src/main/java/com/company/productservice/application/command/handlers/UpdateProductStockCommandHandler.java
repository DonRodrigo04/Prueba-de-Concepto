package com.company.productservice.application.command.handlers;

import com.company.productservice.application.command.models.UpdateProductStockCommand;
import com.company.productservice.application.common.ApplicationException;
import com.company.productservice.application.common.handlers.CommandHandler;
import com.company.productservice.application.events.DomainEventPublisher;
import com.company.productservice.application.events.ProductStockUpdatedEvent;
import com.company.productservice.domain.model.Product;
import com.company.productservice.domain.repository.ProductRepository;
/**
 * Manejador del comando UpdateProductStockCommand
 * Implementa la lógica para actualizar el stock de un producto
 */
public class UpdateProductStockCommandHandler implements CommandHandler<UpdateProductStockCommand, Void> {
    private final ProductRepository productRepository;
    private final DomainEventPublisher eventPublisher;

    public UpdateProductStockCommandHandler(
            ProductRepository productRepository,
            DomainEventPublisher eventPublisher) {
        this.productRepository = productRepository;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public Void handle(UpdateProductStockCommand command) {
        // Buscar el producto
        Product product = productRepository.findById(command.getProductId())
                .orElseThrow(() -> new ApplicationException("Product not found", "PRODUCT_NOT_FOUND"));

        // Verificar que el producto esté activo
        if (!product.isActive()) {
            throw new ApplicationException("Cannot update stock of inactive product", "PRODUCT_INACTIVE");
        }

        // Guardar el stock actual para el evento
        int oldStock = product.getStockQuantity();

        // Actualizar el stock
        product.updateStock(command.getNewStockQuantity());

        // Persistir los cambios
        productRepository.save(product);

        // Determinar el tipo de actualización
        String updateType = oldStock < command.getNewStockQuantity() ? "INCREASE" : "DECREASE";

        // Publicar evento de dominio
        eventPublisher.publish(new ProductStockUpdatedEvent(
                product.getId(),
                product.getName(),
                oldStock,
                product.getStockQuantity(),
                updateType
        ));

        return null;
    }
}