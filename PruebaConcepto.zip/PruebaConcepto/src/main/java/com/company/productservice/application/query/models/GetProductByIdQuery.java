package com.company.productservice.application.query.models;
import com.company.productservice.application.common.Query;
import java.util.UUID;
/**
 * Consulta para obtener un producto por su ID
 * Devuelve un ProductDto con los datos del producto
 */
public class GetProductByIdQuery implements Query<ProductDto> {
    private final UUID productId;

    public GetProductByIdQuery(UUID productId) {
        this.productId = productId;
    }

    public UUID getProductId() {
        return productId;
    }
}