package com.company.productservice.application.common.bus;
import com.company.productservice.application.common.Query;
/**
 * Bus de consultas que actúa como punto central para la ejecución de consultas
 * Implementa el patrón Mediator para desacoplar consultas de sus manejadores
 */
public interface QueryBus {
    /**
     * Ejecuta una consulta y devuelve su resultado
     *
     * @param query La consulta a ejecutar
     * @return El resultado de la ejecución de la consulta
     */
    <R> R execute(Query<R> query);
}