package com.company.productservice.application.common.handlers;
import com.company.productservice.application.common.Query;
/**
 * Interfaz base para todos los manejadores de consultas
 * Cada consulta tiene un manejador específico que implementa la lógica de ejecución.
 *
 * @param <Q> Tipo de consulta
 * @param <R> Tipo de respuesta
 */
public interface QueryHandler<Q extends Query<R>, R> {
    /**
     * Ejecuta la consulta y devuelve el resultado
     *
     * @param query Consulta a ejecutar
     * @return Resultado de la ejecución de la consulta
     */
    R handle(Q query);
}