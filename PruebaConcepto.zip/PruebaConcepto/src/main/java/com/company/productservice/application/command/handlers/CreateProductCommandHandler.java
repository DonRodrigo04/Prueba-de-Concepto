package com.company.productservice.application.command.handlers;
import com.company.productservice.application.command.models.CreateProductCommand;
import com.company.productservice.application.common.ApplicationException;
import com.company.productservice.application.common.handlers.CommandHandler;
import com.company.productservice.application.events.DomainEventPublisher;
import com.company.productservice.application.events.ProductCreatedEvent;
import com.company.productservice.domain.model.Product;
import com.company.productservice.domain.repository.ProductRepository;
import java.util.UUID;
/**
 * Manejador del comando CreateProductCommand
 * Implementa la lógica para crear un nuevo producto
 */
public class CreateProductCommandHandler implements CommandHandler<CreateProductCommand, String> {
    private final ProductRepository productRepository;
    private final DomainEventPublisher eventPublisher;

    public CreateProductCommandHandler(
            ProductRepository productRepository,
            DomainEventPublisher eventPublisher) {
        this.productRepository = productRepository;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public String handle(CreateProductCommand command) {
        // Validar si el producto ya existe con el mismo SKU
        if (productRepository.existsBySku(command.getSku())) {
            throw new ApplicationException("Product with SKU already exists", "PRODUCT_SKU_ALREADY_EXISTS");
        }

        // Crear la entidad de dominio
        Product product = new Product(
                command.getName(),
                command.getDescription(),
                command.getSku(),
                command.getPrice(),
                command.getStockQuantity(),
                command.getCategory()
        );

        // Persistir el producto
        Product savedProduct = productRepository.save(product);

        // Publicar evento de dominio
        eventPublisher.publish(new ProductCreatedEvent(
                savedProduct.getId(),
                savedProduct.getName(),
                savedProduct.getSku(),
                savedProduct.getPrice(),
                savedProduct.getCategory()
        ));

        // Devolver el ID del producto creado
        return savedProduct.getId().toString();
    }
}