package com.company.productservice.application.events;
/**
 * Publicador de eventos de dominio
 * Permite a otros componentes suscribirse a eventos específicos
 */
public interface DomainEventPublisher {
    //Publica un evento para que sea procesado por los suscriptores
    void publish(DomainEvent event);
}