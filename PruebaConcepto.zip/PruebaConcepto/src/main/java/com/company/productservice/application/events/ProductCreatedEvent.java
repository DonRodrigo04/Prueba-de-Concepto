package com.company.productservice.application.events;
import java.math.BigDecimal;
import java.util.UUID;
/**
 * Evento que se dispara cuando se crea un nuevo producto
 */
public class ProductCreatedEvent extends DomainEvent {
    private final UUID productId;
    private final String name;
    private final String sku;
    private final BigDecimal price;
    private final String category;

    public ProductCreatedEvent(UUID productId, String name, String sku, BigDecimal price, String category) {
        super();
        this.productId = productId;
        this.name = name;
        this.sku = sku;
        this.price = price;
        this.category = category;
    }

    public UUID getProductId() {
        return productId;
    }

    public String getName() {
        return name;
    }

    public String getSku() {
        return sku;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public String getEventType() {
        return "PRODUCT_CREATED";
    }
}