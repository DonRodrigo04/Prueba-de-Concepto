package com.company.productservice.application.common.bus;

import com.company.productservice.application.common.Query;
import com.company.productservice.application.common.handlers.QueryHandler;
import java.util.HashMap;
import java.util.Map;
/**
 * Implementación simple del bus de consultas
 * Mantiene un registro de manejadores para cada tipo de consulta
 */
public class SimpleQueryBus implements QueryBus {
    // Mapa que asocia tipos de consultas con sus manejadores
    private final Map<Class<?>, QueryHandler<?, ?>> handlers = new HashMap<>();

    /**
     * Registra un manejador para un tipo específico de consulta
     *
     * @param queryClass Clase de la consulta
     * @param handler Manejador de la consulta
     */
    public <Q extends Query<R>, R> void register(Class<Q> queryClass, QueryHandler<Q, R> handler) {
        handlers.put(queryClass, handler);
    }

    /**
     * Ejecuta una consulta usando su manejador registrado
     *
     * @param query La consulta a ejecutar
     * @return El resultado de la ejecución de la consulta
     * @throws IllegalArgumentException si no hay un manejador registrado para la consulta
     */
    @SuppressWarnings("unchecked")
    @Override
    public <R> R execute(Query<R> query) {
        QueryHandler<Query<R>, R> handler = (QueryHandler<Query<R>, R>) handlers.get(query.getClass());
        if (handler == null) {
            throw new IllegalArgumentException("No handler registered for " + query.getClass().getName());
        }
        return handler.handle(query);
    }
}