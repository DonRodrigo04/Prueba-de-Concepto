package com.company.productservice.application.command.models;
import com.company.productservice.application.common.Command;
import java.math.BigDecimal;
import java.util.UUID;
/**
 * Comando para actualizar el precio de un producto
 * Contiene el ID del producto y el nuevo precio
 * No devuelve ningún valor (void)
 */
public class UpdateProductPriceCommand implements Command<Void> {
    private final UUID productId;
    private final BigDecimal newPrice;

    public UpdateProductPriceCommand(UUID productId, BigDecimal newPrice) {
        this.productId = productId;
        this.newPrice = newPrice;
    }

    public UUID getProductId() {
        return productId;
    }

    public BigDecimal getNewPrice() {
        return newPrice;
    }
}