package com.company.productservice.application.command.models;
import com.company.productservice.application.common.Command;
import java.util.UUID;
/**
 * Comando para desactivar un producto
 * Contiene el ID del producto
 * No devuelve ningún valor (void)
 */
public class DeactivateProductCommand implements Command<Void> {
    private final UUID productId;

    public DeactivateProductCommand(UUID productId) {
        this.productId = productId;
    }

    public UUID getProductId() {
        return productId;
    }
}