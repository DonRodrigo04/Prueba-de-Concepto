package com.company.productservice.application.query.models;
import com.company.productservice.application.common.Query;
import java.util.List;
/**
 * Consulta para buscar productos con criterios de filtrado y paginación
 * Devuelve una lista de ProductDto que cumplen los criterios
 */
public class FindProductsQuery implements Query<List<ProductDto>> {
    private final String nameFilter;
    private final String categoryFilter;
    private final Double minPrice;
    private final Double maxPrice;
    private final Boolean onlyActive;
    private final int page;
    private final int size;

    public FindProductsQuery(String nameFilter, String categoryFilter,
                             Double minPrice, Double maxPrice,
                             Boolean onlyActive, int page, int size) {
        this.nameFilter = nameFilter;
        this.categoryFilter = categoryFilter;
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
        this.onlyActive = onlyActive;
        this.page = page;
        this.size = size;
    }

    public String getNameFilter() {
        return nameFilter;
    }

    public String getCategoryFilter() {
        return categoryFilter;
    }

    public Double getMinPrice() {
        return minPrice;
    }

    public Double getMaxPrice() {
        return maxPrice;
    }

    public Boolean getOnlyActive() {
        return onlyActive;
    }

    public int getPage() {
        return page;
    }

    public int getSize() {
        return size;
    }
}