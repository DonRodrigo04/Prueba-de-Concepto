package com.company.productservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal para iniciar la aplicación del servicio de productos.
 * Sirve como punto de entrada para la aplicación Spring Boot.
 */
@SpringBootApplication
public class Main {

    /**
     * Método principal que inicia la aplicación Spring Boot.
     *
     * @param args argumentos de línea de comandos pasados al iniciar la aplicación
     */
    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);

        System.out.println("------------------------------------------------");
        System.out.println("  Servicio de Productos iniciado correctamente  ");
        System.out.println("------------------------------------------------");
        System.out.println("Accede a la API en: http://localhost:8080/api");
        System.out.println("Documentación Swagger: http://localhost:8080/api/swagger-ui.html");
        System.out.println("Consola H2 (base de datos): http://localhost:8080/api/h2-console");
        System.out.println("------------------------------------------------");
    }
}