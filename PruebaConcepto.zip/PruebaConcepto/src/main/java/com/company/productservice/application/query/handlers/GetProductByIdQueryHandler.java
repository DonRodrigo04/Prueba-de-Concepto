package com.company.productservice.application.query.handlers;
import com.company.productservice.application.common.ApplicationException;
import com.company.productservice.application.common.handlers.QueryHandler;
import com.company.productservice.application.query.models.GetProductByIdQuery;
import com.company.productservice.application.query.models.ProductDto;
import com.company.productservice.domain.model.Product;
import com.company.productservice.domain.repository.ProductRepository;
import java.time.format.DateTimeFormatter;
/**
 * Manejador de la consulta GetProductByIdQuery
 * Implementa la lógica para obtener un producto por su ID
 */
public class GetProductByIdQueryHandler implements QueryHandler<GetProductByIdQuery, ProductDto> {
    private final ProductRepository productRepository;
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public GetProductByIdQueryHandler(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public ProductDto handle(GetProductByIdQuery query) {
        // Buscar el producto
        Product product = productRepository.findById(query.getProductId())
                .orElseThrow(() -> new ApplicationException("Product not found", "PRODUCT_NOT_FOUND"));

        // Mapear el producto a DTO
        return mapToDto(product);
    }

    private ProductDto mapToDto(Product product) {
        return new ProductDto(
                product.getId(),
                product.getName(),
                product.getDescription(),
                product.getSku(),
                product.getPrice(),
                product.getStockQuantity(),
                product.getCategory(),
                product.isActive(),
                product.getCreatedAt().format(DATE_FORMATTER),
                product.getUpdatedAt().format(DATE_FORMATTER)
        );
    }
}