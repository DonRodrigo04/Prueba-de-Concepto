package com.company.productservice.domain.model;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;
/**
 * Entidad de dominio que representa un producto en el sistema.
 * Contiene la lógica de negocio relacionada con productos.
 */
public class Product {
    private UUID id;
    private String name;
    private String description;
    private String sku;
    private BigDecimal price;
    private int stockQuantity;
    private String category;
    private boolean active;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    //Constructor para crear un nuevo producto
    public Product(String name, String description, String sku, BigDecimal price,
                   int stockQuantity, String category) {
        // Validaciones de dominio
        validateName(name);
        validateSku(sku);
        validatePrice(price);
        validateStockQuantity(stockQuantity);
        validateCategory(category);

        this.id = UUID.randomUUID();
        this.name = name;
        this.description = description;
        this.sku = sku;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.category = category;
        this.active = true;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    //Constructor protegido para JPA
    protected Product() {
        // Constructor necesario para JPA
    }

    //Actualiza los detalles del producto
    public void updateDetails(String name, String description, String category) {
        validateName(name);
        validateCategory(category);

        this.name = name;
        this.description = description;
        this.category = category;
        this.updatedAt = LocalDateTime.now();
    }

    //Actualiza el precio del producto
    public void updatePrice(BigDecimal price) {
        validatePrice(price);

        this.price = price;
        this.updatedAt = LocalDateTime.now();
    }

    //Actualiza el stock del producto
    public void updateStock(int stockQuantity) {
        validateStockQuantity(stockQuantity);

        this.stockQuantity = stockQuantity;
        this.updatedAt = LocalDateTime.now();
    }

    //Desactiva el producto
    public void deactivate() {
        this.active = false;
        this.updatedAt = LocalDateTime.now();
    }

    //Activa el producto
    public void activate() {
        this.active = true;
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Reduce el stock en la cantidad especificada
     * @return true si hay suficiente stock, false en caso contrario
     */
    public boolean decreaseStock(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }

        if (quantity > stockQuantity) {
            return false;
        }

        this.stockQuantity -= quantity;
        this.updatedAt = LocalDateTime.now();
        return true;
    }

    //Incrementa el stock en la cantidad especificada
    public void increaseStock(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }

        this.stockQuantity += quantity;
        this.updatedAt = LocalDateTime.now();
    }

    // Validaciones de dominio
    private void validateName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Product name cannot be empty");
        }

        if (name.length() > 100) {
            throw new IllegalArgumentException("Product name cannot exceed 100 characters");
        }
    }

    private void validateSku(String sku) {
        if (sku == null || sku.trim().isEmpty()) {
            throw new IllegalArgumentException("SKU cannot be empty");
        }

        if (!sku.matches("^[A-Z0-9-]{3,20}$")) {
            throw new IllegalArgumentException("SKU must be 3-20 characters and contain only uppercase letters, numbers and hyphens");
        }
    }

    private void validatePrice(BigDecimal price) {
        if (price == null) {
            throw new IllegalArgumentException("Price cannot be null");
        }

        if (price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Price must be positive");
        }
    }

    private void validateStockQuantity(int stockQuantity) {
        if (stockQuantity < 0) {
            throw new IllegalArgumentException("Stock quantity cannot be negative");
        }
    }

    private void validateCategory(String category) {
        if (category == null || category.trim().isEmpty()) {
            throw new IllegalArgumentException("Category cannot be empty");
        }
    }

    // Getters
    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getSku() { return sku; }
    public BigDecimal getPrice() { return price; }
    public int getStockQuantity() { return stockQuantity; }
    public String getCategory() { return category; }
    public boolean isActive() { return active; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    // Setters protegidos para JPA
    protected void setId(UUID id) { this.id = id; }
    protected void setName(String name) { this.name = name; }
    protected void setDescription(String description) { this.description = description; }
    protected void setSku(String sku) { this.sku = sku; }
    protected void setPrice(BigDecimal price) { this.price = price; }
    protected void setStockQuantity(int stockQuantity) { this.stockQuantity = stockQuantity; }
    protected void setCategory(String category) { this.category = category; }
    protected void setActive(boolean active) { this.active = active; }
    protected void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    protected void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return Objects.equals(id, product.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}