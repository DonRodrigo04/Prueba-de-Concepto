package com.company.productservice.application.query.models;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * DTO (Data Transfer Object) para transferir datos de productos
 * Contiene solo los datos necesarios para la visualización
 * Usado en las respuestas de las consultas
 */
public class ProductDto {
    private final UUID id;
    private final String name;
    private final String description;
    private final String sku;
    private final BigDecimal price;
    private final int stockQuantity;
    private final String category;
    private final boolean active;
    private final String createdAt;
    private final String updatedAt;

    public ProductDto(UUID id, String name, String description, String sku,
                      BigDecimal price, int stockQuantity, String category,
                      boolean active, String createdAt, String updatedAt) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.sku = sku;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.category = category;
        this.active = active;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters
    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getSku() { return sku; }
    public BigDecimal getPrice() { return price; }
    public int getStockQuantity() { return stockQuantity; }
    public String getCategory() { return category; }
    public boolean isActive() { return active; }
    public String getCreatedAt() { return createdAt; }
    public String getUpdatedAt() { return updatedAt; }
}