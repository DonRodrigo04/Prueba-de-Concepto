package com.company.productservice.infrastructure.persistence;

import com.company.productservice.domain.model.Product;
import com.company.productservice.domain.repository.ProductRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Implementación del repositorio de dominio ProductRepository
 * Actúa como adaptador entre el dominio y la capa de infraestructura JPA
 */
@Component
public class JpaProductRepositoryAdapter implements ProductRepository {
    private final JpaProductRepository jpaRepository;

    public JpaProductRepositoryAdapter(JpaProductRepository jpaRepository) {
        this.jpaRepository = jpaRepository;
    }

    @Override
    public Product save(Product product) {
        return jpaRepository.save(product);
    }

    @Override
    public Optional<Product> findById(UUID id) {
        return jpaRepository.findById(id);
    }

    @Override
    public Optional<Product> findBySku(String sku) {
        return jpaRepository.findBySku(sku);
    }

    @Override
    public boolean existsBySku(String sku) {
        return jpaRepository.existsBySku(sku);
    }

    @Override
    public List<Product> findByFilters(String nameFilter, String categoryFilter,
                                       Double minPrice, Double maxPrice,
                                       Boolean onlyActive, int page, int size) {
        return jpaRepository.findByFilters(
                nameFilter,
                categoryFilter,
                minPrice,
                maxPrice,
                onlyActive,
                PageRequest.of(page, size)
        );
    }

    @Override
    public void delete(Product product) {
        jpaRepository.delete(product);
    }

    @Override
    public long count() {
        return jpaRepository.count();
    }
}