package com.company.productservice.application.events;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Clase base para todos los eventos de dominio
 * Sigue el patrón Event Sourcing
 */
public abstract class DomainEvent {
    private final UUID eventId;
    private final LocalDateTime occurredOn;

    protected DomainEvent() {
        this.eventId = UUID.randomUUID();
        this.occurredOn = LocalDateTime.now();
    }

    public UUID getEventId() {
        return eventId;
    }

    public LocalDateTime getOccurredOn() {
        return occurredOn;
    }

    /**
     * Devuelve el tipo del evento como una cadena
     * Útil para categorizar y filtrar eventos
     * @return Tipo del evento
     */
    public abstract String getEventType();
}