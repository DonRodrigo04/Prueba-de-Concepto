package com.company.productservice.application.command.models;
import com.company.productservice.application.common.Command;
import java.util.UUID;
/**
 * Comando para actualizar el stock de un producto
 * Contiene el ID del producto y la cantidad a actualizar
 * No devuelve ningún valor (void)
 */
public class UpdateProductStockCommand implements Command<Void> {
    private final UUID productId;
    private final int newStockQuantity;

    public UpdateProductStockCommand(UUID productId, int newStockQuantity) {
        this.productId = productId;
        this.newStockQuantity = newStockQuantity;
    }

    public UUID getProductId() {
        return productId;
    }

    public int getNewStockQuantity() {
        return newStockQuantity;
    }
}