package com.company.productservice.application.events;
import java.util.UUID;
/**
 * Evento que se dispara cuando se actualiza el stock de un producto
 */
public class ProductStockUpdatedEvent extends DomainEvent {
    private final UUID productId;
    private final String productName;
    private final int oldStock;
    private final int newStock;
    private final String updateType; // "INCREASE" or "DECREASE"

    public ProductStockUpdatedEvent(UUID productId, String productName, int oldStock, int newStock, String updateType) {
        super();
        this.productId = productId;
        this.productName = productName;
        this.oldStock = oldStock;
        this.newStock = newStock;
        this.updateType = updateType;
    }

    public UUID getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public int getOldStock() {
        return oldStock;
    }

    public int getNewStock() {
        return newStock;
    }

    public String getUpdateType() {
        return updateType;
    }

    @Override
    public String getEventType() {
        return "PRODUCT_STOCK_UPDATED";
    }
}