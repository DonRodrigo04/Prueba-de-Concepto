package com.company.productservice.application.common.bus;
import com.company.productservice.application.common.Command;
/**
 * Bus de comandos que actúa como punto central para la ejecución de comandos
 * Implementa el patrón Mediator para desacoplar comandos de sus manejadores
 */
public interface CommandBus {
    /**
     * Ejecuta un comando y devuelve su resultado
     *
     * @param command El comando a ejecutar
     * @return El resultado de la ejecución del comando
     */
    <R> R execute(Command<R> command);
}